
package com.ellago;

public class Primerproyecto {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("buenas!!!!");
		int x = 5;
		int y = 6;
		System.out.println(x+y);
	}

}
