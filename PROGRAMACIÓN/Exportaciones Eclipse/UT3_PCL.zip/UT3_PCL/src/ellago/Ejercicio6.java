package ellago;
/**
 * 
 * @author Pablo Coba Lodín
 */
public class Ejercicio6 {

	public static void main(String[] args) {
		//6.Realiza un programa que muestre por pantalla los 50 primeros números pares.
		int i = 2;
		System.out.println("estos son los números pares del 1 al 50:");

		do {
			System.out.print(i+", ");
			i=i+2;
		}while(i<=50);
	}
	
	

}
