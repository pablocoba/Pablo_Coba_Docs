package ellago;

public class Ejercicio3 {
	////////////////////////////////////////////
	static int Valormax = 999999; //valor estático
	////////////////////////////////////////////
	public static void main(String[] args) {
		/*
		 3.- Dado el siguiente programa, modifícalo para utilizar las variables que se indican. El tipo de dato elegido debe ser el de menos bits posibles que puedan representar el valor. Justifica tu elección.
			1. Si un empleado está casado o no.
			2. Valor máximo no modificable: 999999.
			3. Día de la semana
			4. Día del año.
			5. Sexo: con dos valores posibles 'V' o 'M'
			6. Milisegundos transcurridos desde el 01/01/1970 hasta nuestros días.
			7. Almacenar el total de una factura
			8. Población mundial del planeta tierra.
			*/



			boolean casado = false; //casado o no
			byte dia_semana; //día semana
			short dia_año; //día año
			char male = 'M'; 
			char female = 'F';
			char sexo=(male==female)?'M':'F'; //sexo con hombre o mujer
			long miliseg; //milisegundos
			float totalfactura; //factura
			long poblaciónmundial; //población


	}

}
