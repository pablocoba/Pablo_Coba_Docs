package ellago;

import java.util.Scanner;

public class Ejercicio1 {

	public static void main(String[] args) {
		



			/*1.- Dados los siguientes identificadores, indicar si son válidos o no. Justificar las respuestas.

				1. mi variable - no válido(espacios)
				2. num_de_cte - válido
				3. ____programa - válido
				4. $alguna - válido
				5. 3tema - no válido (empieza por un dígito)
				6. cierto? - no válido: simbolos especiales
				7. númerodeCliente - válido
				8. jose~ - no válido - símbolos especiales
				9. año - válido
				10. PI - válido
				11.int - no válido, palabra reservada
			*/
			
		
		
	 		
	 		
		}
}
		

	


