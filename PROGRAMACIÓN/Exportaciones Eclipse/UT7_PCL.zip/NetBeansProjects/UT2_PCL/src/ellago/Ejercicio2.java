package ellago;

public class Ejercicio2 {

	public static void main(String[] args) {

		/*
		2.- Indica los errores presentes en el siguiente código:

			1. / --> faltan asteriscos para hacerlo comentario
			2. operadoresaritmeticos.java
			3. Programa que muestra el uso de los operadores aritméticos
			4. / --> faltan asteriscos para hacerlo comentario
			5. public class operadoresaritmeticos {
			6. public static main(String[] args) --> falta el void entre static y main
			7. short x = 7; 
			8. int y = 5;
			9. float f1 = 13.5; --> falta la f de float en el valor.
			10. float f2 = 8f;
			11. System.out.println("El valor de x es ", x, " y el valor de y es ", y); --> No irían comas, sino "+", tal que así: ("El valor de x es " + x + " y el valor de y es " + y).
			12. System.out.println("El resultado de x + y es " + (x + y)); 
			13. System.out.println("El resultado de x - y es " + (x - y));
			14. System.out.printf("\n%s%s\n","División entera:","x / y = ",(x/y)); --> la línea corregida es "System.out.printf("\n%s %s\n" + "División entera: x / y = " + (x/y),x,y);" (sin comillas)
			15. System.out.println("Resto de la división entera: x % y = " + (x % y));
			16. System.out.printf("El valor de f1 es %f y el de f2 es %f\n",f1,f2);
			17. System.out.println("El resultado de f1 / f2 es " + (f1 / f2)) --> falta un ";" al final
			18. }
			*/
	}

}
